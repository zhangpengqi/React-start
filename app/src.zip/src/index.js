import React from "react";
import {render} from "react-dom";
// import Reg from "./components/reg"
import "./style.css"
// import"./components/login"
// import axios from "axios"
//自定义组件
import Search from "./components/search";
import Nav from "./components/nav";
import Banner from "./components/banner";
import Article from "./components/article";
import Tabbar from "./components/tabbar";

let index=(
    <div>
        {/*<Reg></Reg>*/}
        {/*分类导航*/}
        <Search></Search>
        {/*分类导航*/}
        <Nav></Nav>
        {/*幻灯片*/}
        <Banner></Banner>
        {/*文章列表*/}
        <Article></Article>
        {/*底部导航*/}
        <Tabbar></Tabbar>
    </div>
)
render(index,document.getElementById("root"));
